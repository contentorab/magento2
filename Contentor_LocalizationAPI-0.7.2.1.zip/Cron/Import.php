<?php
namespace Contentor\LocalizationApi\Cron;

use Contentor\LocalizationApi\Model\Logger\Logger;
use Contentor\LocalizationApi\Model\Service\ProcessUpdates;
use Magento\Framework\App\ResourceConnection;

/**
 * Class Import
 * @package Contentor\LocalizationApi\Cron
 */
class Import
{
    /**
     * @var ProcessUpdates
     */
    private $processUpdates;

    /**
     * @var Logger
     */
    private $logger;
    /**
     * @var ResourceConnection
     */
    private $resource;

    /**
     * Import constructor.
     * @param Logger $logger
     * @param ResourceConnection $resource
     * @param ProcessUpdates $processUpdates
     */
    public function __construct(
        Logger $logger,
        ResourceConnection $resource,
        ProcessUpdates $processUpdates
    ) {
        $this->processUpdates = $processUpdates;
        $this->logger = $logger;
        $this->resource = $resource;
    }

    /**
     * @return $this|bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $connection = $this->resource->getConnection('core_read');

        $lastRun = $this->get($connection, 'lastRun');
        $lastStateChange = $this->get($connection, 'lastStateChange');

        if(empty($lastStateChange)) {
            $this->logger->info('Running initial content synchronization');
        } else {
            $this->logger->info('Running content synchronization, last state change seen ' . $lastStateChange . ' (at ' . $lastRun . ')');
        }

        while(true) {
            $result = $this->processUpdates->execute(
                empty($lastStateChange) ? gmdate('c', strtotime('-2 days')) : $lastStateChange
            );

            // Save the new last state change and then continue
            $this->update($connection, 'lastStateChange', $result['lastStateChange'], $lastStateChange);
            $lastStateChange = $result['lastStateChange'];

            if($result['updates'] == 0) {
                break;
            }
        }

        $this->update($connection, 'lastRun', gmdate('c'), $lastRun);

        return $this;
    }

    /**
     * @param $connection
     * @param $key
     * @return null
     */
    private function get($connection, $key) {
        $table = $this->resource->getTableName('contentor_config');
        $query = "SELECT `value` FROM `" . $table . "` WHERE `key` = :key";
        $binds = [
            'key' => $key
        ];
        $date = $connection->fetchOne($query, $binds);
        if(empty($date)) {
            return null;
        } else {
            return $date;
        }
    }

    /**
     * @param $connection
     * @param $key
     * @param $value
     * @param $previous
     */
    private function update($connection, $key, $value, $previous) {
        $table = $this->resource->getTableName('contentor_config');
        if (empty($previous)) {
            $query = "INSERT INTO `" . $table . "` (`key`, `value`) VALUES (:key, :value)";
        } else {
            $query = "UPDATE `" . $table . "` SET `value` = :value WHERE `key` = :key";
        }

        $binds = [
            'key' => $key,
            'value' => $value
        ];
        $connection->query($query, $binds);
    }
}
